# Control_Swap_zRam
Sencilla aplicación que permite ajustar el uso de la memoria virtual (swap) &amp; Activar / Desactivar Swap/zRam

Esta sencilla aplicación cumple diversos propósitos.
**El primero** es el de poder ajustar el valor de la **swappiness**.

Si están utilizando *Ubuntu* por ejemplo y no han modificado este valor, seguramente sea de **60**. En *mx-Linux* el valor por defecto es de **15**.

**La segunda** función que tiene el programa es la de *activar/desactivar* completamente la **swap**.

**La tercera** función permite *activar/desactivar* el uso de la zRAM.

Más información en: [The Nerdy Apprentice](https://thenerdyapprentice.blogspot.com)